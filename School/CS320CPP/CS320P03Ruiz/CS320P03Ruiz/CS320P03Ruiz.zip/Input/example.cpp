#include <iostream>
using namespace std;
int main()
{
	int x, y;
	cin >> x; cin >> y;
	cout << x + y + x << endl;
	return 0;
}