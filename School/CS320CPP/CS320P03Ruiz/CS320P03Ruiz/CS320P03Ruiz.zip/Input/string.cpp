#include <iostream>
using namespace std;
int main() {
	double x;
	double y;
	int intSum;
	cout << "Hello World!";
	cout << "Enter a number to add";
	cin >> x;
	cout << "Enter another number to add";
	cin >> y;
	intSum = x + y;
	cout << endl << "Int sum is " << intSum;
}